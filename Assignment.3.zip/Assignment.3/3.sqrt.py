from math import sqrt
def sroot(n):
    #Enter any number, say 30, as the last guess
    lastGuess=30
    nextGuess = (lastGuess + (n / lastGuess)) / 2
    while(abs(lastGuess-nextGuess)>0.0001):
        lastGuess=nextGuess
        nextGuess = (lastGuess + (n / lastGuess)) /2 
    return nextGuess

#For example determine the square root of 225
print(sqrt(225))