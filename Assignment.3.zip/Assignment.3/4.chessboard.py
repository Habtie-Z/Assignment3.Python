import turtle
from turtle import *
chessboard = turtle.Turtle()

canvas = Screen()
canvas.setup(800,400)

#Sets screen characterstics
wn = turtle.Screen()
wn.bgcolor("light grey")
wn.title('Chesboard')

#Sets turtle characterstics
greg = turtle.Turtle()
greg.speed(0)

#draws and fills one square

def square(size, alternate,color):
    greg.color(color)
    greg.begin_fill()
    for i in range(4):
        greg.fd(size)
        greg.lt(90)
    greg.end_fill()
    greg.fd(size)

# draws a row of squares
def row(size, alternate,color1, color2):
    for i in range(4):
        if(alternate==True):
            square(size, alternate,color1)
            square(size, alternate,color2)
        else:
            square(size, alternate,color2)
            square(size, alternate,color1)    
    #draws the whole chessboard
def chessboard(size, alternate,color1, color2):
    greg.pu()
    greg.goto(-(size*9), (size*3))
    
    for i in range(8):
        row(size, alternate,color1, color2)
        greg.bk(size*8)
        greg.rt(90)
        greg.fd(size)
        greg.lt(90)
        if(alternate==True):
            alternate=False
        else:
            alternate=True
chessboard(40, True, 'white', 'black')

#draws the whole chessboard
def chessboard(size, alternate,color1, color2):
    greg.pu()
    
    greg.goto(size, (size*3))
    for i in range(8):
        row(size, alternate,color1, color2)
        greg.bk(size*8)
        greg.rt(90)
        greg.fd(size)
        greg.lt(90)
        if(alternate==True):
            alternate=False
        else:
            alternate=True
chessboard(40, True, 'white', 'black')
