#Credit Card Number Validation

def isValid(number):
       
    number = list(map(int, number))
    x = len(number) - 2
    y = len(number) - 1
    z = 0
    WorkingList = []
   
    while x >= 0 :
        WorkingList.append(number[x] * 2)
        x -= 2
  
    while y >= 0 :
        WorkingList.append(number[y])
        y -= 2

    WorkingListStr = list(map(str , WorkingList))
    WorkingListStr = "".join(WorkingListStr) 
    del WorkingList[:]
    while z < len(WorkingListStr) :
        WorkingList.append(WorkingListStr[z])
        z += 1
    WorkingList = list(map(int , WorkingList))
   
    Mod10 = sum(WorkingList) % 10
 
    if Mod10 == 0 :
        return True
    else :
        return False

CardNumber = input("number : ")
isValidStr = str(CardNumber)

First4 = isValidStr[0] + isValidStr[1] + isValidStr[2] + isValidStr[3]
First2 = isValidStr[0] + isValidStr[1]

if len(isValidStr) > 12 and len(isValidStr) < 17 :
    # Checking for "Visa" Cards
    if isValidStr[0] == "4" :
        CheckBool = isValid(isValidStr)
        if CheckBool == True :
            print(isValidStr, "is a valid 'Visa' Credit Card !")
        else :
            print(isValidStr, "is not a valid 'Visa' Credit Card")
    # Checking for "MasterCards" 
    if isValidStr[0] == "5" :
        CheckBool = isValid(isValidStr)
        if CheckBool == True :
            print(isValidStr, "is a valid 'MasterCard' Credit Card")
        else :
            print(isValidStr, "is not a valid 'MasterCard' Credit Card")
    
    # Checking for "Discover" Cards
    if isValidStr[0] == "6" :
        CheckBool = isValid(isValidStr)
        if CheckBool == True :
            print(isValidStr, "is a valid 'Discover' Credit Card")
        else :
            print(isValidStr, "is not a valid 'Discover' Credit Card")
    
    # Checking for "American Express" Cards
    if First2 == "37" :
        CheckBool = isValid(isValidStr)
        if CheckBool == True :
            print(isValidStr, "is a valid 'American Express' Credit Card")
        else :
            print(isValidStr, "is not a valid 'American Express' Credit Card")

else :
    print("Sorry,", isValidStr, "is not a Credit Card Number!")
