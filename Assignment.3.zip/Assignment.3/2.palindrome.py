# Python Palindrome Program using Functions
 
reverse = 0
def isPalindrome(number):
    global reverse
    
    if(number > 0):
        Reminder = number % 10
        reverse = (reverse * 10) + Reminder
        isPalindrome(number // 10)
    return reverse

number = int(input("Please Enter any Number: "))

rev = isPalindrome(number)
print("Reverse of a Given number is = %d" %rev)

if(number == rev):
    print("%d is a Palindrome Number" %number)
else:
    print("%d is not a Palindrome Number" %number)
