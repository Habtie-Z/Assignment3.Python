from math import sqrt

def getPentagonalNumber(n):
        return n*(3 *n-1)/2

for x in range(1,101):
         print (getPentagonalNumber(x), end=', ')
        
